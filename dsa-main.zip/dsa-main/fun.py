a = '/a/b/c'

print(a.split('/')[1:])

print('/'.split('/')[1:])
print('/a'.split('/')[1:])

grid = [[0] * 3] * 3
print(grid)

grid[0][0] = 4
print(grid)
