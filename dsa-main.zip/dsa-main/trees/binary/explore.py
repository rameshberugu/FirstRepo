from heapq import heappop, heappush, heapify

a = [6, 7, 4, 2, 1]

heapify(a)
print(heappop(a))

print(4 in [3, 4])
