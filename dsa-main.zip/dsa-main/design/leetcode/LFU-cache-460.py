class LFUCache:

    def __init__(self, capacity):
        self.capacity = capacity

    def get(self, key):
        pass

    def put(self, key, value):
        pass
