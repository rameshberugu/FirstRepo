nums = 14
b = 21

print(nums ^ b)
print(nums ^ nums)
print(b ^ b)

x = (4, 3)

nums, b = x
print(nums, b)

nums = [5, 5, 4, 5, 4, 1, 1, 1]
print(nums)