def main(nums):
    n = len(nums)


for nums in [
    [1, 1, 2],
    [0, 0, 1, 1, 1, 2, 2, 3, 3, 4]
]:
    print(main(nums))
