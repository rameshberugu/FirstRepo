from binarytree import heap

print(heap())
print(heap(is_max=False))
print(heap(is_perfect=True))
print(heap(is_max=False, is_perfect=True))
