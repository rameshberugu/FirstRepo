from binarytree import bst

print(bst())
print(bst(is_perfect=True))
