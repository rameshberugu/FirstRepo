from math import inf

nums = -inf
b = inf

print(b - nums)
print(b - 0)
