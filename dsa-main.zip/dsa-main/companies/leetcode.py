# https://leetcode.com/problems/minimum-deletion-cost-to-avoid-repeating-letters/
# https://leetcode.com/problems/minimum-deletions-to-make-character-frequencies-unique/

# Swiggy

# https://leetcode.com/problems/minimum-one-bit-operations-to-make-integers-zero/
# https://leetcode.com/problems/maximum-area-of-a-piece-of-cake-after-horizontal-and-vertical-cuts/
