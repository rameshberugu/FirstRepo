# https://www.geeksforgeeks.org/minimum-characters-required-to-be-removed-to-make-frequency-of-each-character-unique/

# Swiggy

# https://snippets.cacher.io/snippet/e08f0fec1e61bf8f22a6
# https://www.codingninjas.com/codestudio/problem-details/break-the-prison_1755915
# https://leetcode.com/discuss/interview-question/1002082/twillio-oa-prison-break
# https://www.geeksforgeeks.org/minimum-number-of-given-operations-required-to-be-performed-to-reduce-n-to-0/
