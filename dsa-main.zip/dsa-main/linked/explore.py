nums = 1
b = 2
c = 3

c, e, f = 8, b, c + 1

print(c, e, f)


