print(max([4, 5, 6], default=10))
print(max([], default=10))

s = ' 242-100 + 2 '
print(s.replace(' ', ''))

nums = [1, 2, 3]

print(nums.pop(), nums.pop())

print(int(-13 / 4))


def foo(num):
    print(type(num))


foo(int('5'))

print('-11'.isdigit())

print(int('-11'))
