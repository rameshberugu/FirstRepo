Python Intro to Python Classes
	https://www.w3schools.com/python/python_intro.asp 
	https://www.w3schools.com/python/python_classes.asp

https://www.edureka.co/blog/data-structures-in-python/
https://www.dataquest.io/blog/data-structures-in-python/
https://www.javatpoint.com/data-structures-and-algorithms-in-python-set-1