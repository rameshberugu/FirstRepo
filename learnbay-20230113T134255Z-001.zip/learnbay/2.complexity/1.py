https://www.youtube.com/playlist?list=PLDN4rrl48XKpZkf03iYFl-O29szjTrs_O
	1. Introduction to Algorithms
	1.1 Priori Analysis and Posteriori Testing
	1.2 Characterstics of Algorithm
	1.3 How Write and Analyze Algorithm
	1.4 Frequency Count Method
	1.5.1 Time Complexity #1
	1.5.2 Time Complexity Example #2
	1.5.3 Time Complexity of While and if #3
	1.6 Classes of functions
	1.7 Compare Class of Functions

https://www.youtube.com/watch?v=dwApFR-MpLk&list=PLLX0OlcGRiD7J4lw7-Sg1simLB7LeSbJd&index=2
https://medium.com/fintechexplained/time-complexities-of-python-data-structures-ddb7503790ef
https://dev.to/global_codess/time-complexities-of-python-data-structures-3bja
https://wiki.python.org/moin/TimeComplexity