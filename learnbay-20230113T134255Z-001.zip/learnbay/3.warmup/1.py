Class
	https://leetcode.com/problems/reverse-integer/
	https://leetcode.com/problems/trapping-rain-water/
	https://leetcode.com/problems/spiral-matrix/
	
Homework
	https://leetcode.com/problems/roman-to-integer/
	https://leetcode.com/problems/integer-to-roman/
	https://leetcode.com/problems/robot-bounded-in-circle/
	https://leetcode.com/problems/range-addition/
	https://www.geeksforgeeks.org/python-using-2d-arrays-lists-the-right-way/

	
	