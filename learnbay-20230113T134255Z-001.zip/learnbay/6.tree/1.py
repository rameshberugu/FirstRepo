The Art and Craft of Programming Python Edition
	Chapter 13 Loops
	Chapter 16 Recursion
	Chapter 17 Comparing Recursion and Loopping